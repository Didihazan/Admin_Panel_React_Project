class CarClass{
  constructor(){

  }

  static showCar(_car){
    console.log("Your car:",_car);
  }

  static showYear(_year){
    console.log("Year of car:",_year);
  }
}

// export default 
module.exports = CarClass