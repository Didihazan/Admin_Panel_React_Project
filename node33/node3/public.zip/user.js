exports.showName = (_name) => {
  console.log("Your name is:",_name);
}

exports.showAge = (_age) => {
  console.log("Your age is:",_age);
}

// export רגיל
// exports.showName = showName