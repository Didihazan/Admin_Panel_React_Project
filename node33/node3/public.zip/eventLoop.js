console.log("event loop");

setInterval(() => {
  console.log("byeee 33333");
},1000)